﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace KT1_3
{
    // Окно, отображающее список заказов
    public partial class flightWindow : Window
    {
        private List<Order> ordersList; // Список заказов

        // Конструктор класса flightWindow
        public flightWindow()
        {
            InitializeComponent();

            // Получаем список заказов из базы данных и присваиваем его к ordersList
            ordersList = DatabaseHelper.GetOrders();

            // Устанавливаем ordersList в качестве источника данных для DataGrid
            ordersDataGrid.ItemsSource = ordersList;
        }

        // Обработчик события нажатия на кнопку "Выйти"
        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            // Создаем экземпляр MainWindow и отображаем его
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();

            // Закрываем текущее окно
            Close();
        }
    }
}
