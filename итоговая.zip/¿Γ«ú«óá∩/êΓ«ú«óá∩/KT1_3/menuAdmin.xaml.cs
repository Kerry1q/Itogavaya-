﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace KT1_3
{
    /// <summary>
    /// Логика взаимодействия для menuAdmin.xaml
    /// </summary>
    public partial class menuAdmin : Window
    {
        public menuAdmin()
        {
            InitializeComponent();
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            // Получить значения из текстовых полей
            string flightDirection = txtFlightDirection.Text;
            int flightId = Convert.ToInt32(txtFlightId.Text);
            string airplane = txtAirplane.Text;
            string airline = txtAirline.Text;
            string arrivalTime = txtArrivalTime.Text;
            string departureTime = txtDepartureTime.Text;

            // Создать новый объект Order с полученными данными
            Order newOrder = new Order
            {
                flightDirection = flightDirection,
                flightId = flightId,
                airplane = airplane,
                airline = airline,
                arrivalTime = arrivalTime,
                departureTime = departureTime
            };

            // Добавить новый заказ в базу данных
            DatabaseHelper.AddOrder(newOrder);

            // Очистить текстовые поля после добавления заказа
            txtFlightDirection.Text = "";
            txtFlightId.Text = "";
            txtAirplane.Text = "";
            txtAirline.Text = "";
            txtArrivalTime.Text = "";
            txtDepartureTime.Text = "";
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Close();
        }
    }
}
