﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KT1_3
{
    public class Order
    {
        public string flightDirection { get; set; }
        public int flightId { get; set; }
        public string airplane { get; set; }
        public string airline { get; set; }
        public string arrivalTime { get; set; }
        public string departureTime { get; set; }
    }
}
